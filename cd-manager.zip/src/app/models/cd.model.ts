export interface Cd {
    //{title:'Empire Burlesque', artist:'Bob Dylan', country:'USA',year:1985,price:10.9,company:'Columbia'}
    title:string;
    artist:string;
    country:string;
    year:number;
    price:number;
    company:string;
}
